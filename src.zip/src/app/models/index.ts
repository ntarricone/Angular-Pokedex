export { PokemonList } from "./pokemon-list.interface";
export { PokemonPackage } from "./pokemon-package";
