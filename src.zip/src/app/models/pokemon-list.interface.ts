export interface PokemonList{
    id: Number;
    name: String;
    url: String;
}