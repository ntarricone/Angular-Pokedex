import { Component, OnInit } from '@angular/core';
import { PokemonList } from 'src/app/models';
import { HeroService } from 'src/app/services/hero.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  pokemonList: PokemonList[];
  constructor(private readonly heroService: HeroService){} //inyectable
  
  ngOnInit(): void{
    this.heroService
    .getHeroes()
    .subscribe( pokemon => this.pokemonList = pokemon.results)
  }

}
