import { Injectable } from '@angular/core';

import{environment} from "../../environments/environment"
import { HttpClient } from '@angular/common/http';
import { PokemonPackage } from '../models';
import { PokemonList } from '../models';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HeroService {
  api_url = environment.api_url; //propiedad de clase, no necesitas declararla
  constructor(private readonly http: HttpClient) { } //agregar http

  getHeroes(): Observable<PokemonPackage>{
   return this.http.get<PokemonPackage>(`${this.api_url}/pokemon?limit=807`);
  }
}
